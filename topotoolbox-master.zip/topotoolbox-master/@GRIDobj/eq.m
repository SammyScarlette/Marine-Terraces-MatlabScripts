function OUT = eq(varargin)

funname = 'eq';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});
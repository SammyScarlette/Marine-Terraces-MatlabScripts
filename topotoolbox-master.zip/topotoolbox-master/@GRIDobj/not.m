function I = not(I)


I.Z = ~I.Z;
I.name = ['not(' I.name ')'];
function tf = any(I)


tf = any(I.Z(:));
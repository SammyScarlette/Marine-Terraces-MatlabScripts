function OUT = rdivide(varargin)

funname = 'rdivide';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});
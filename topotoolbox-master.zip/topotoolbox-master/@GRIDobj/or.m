function OUT = or(varargin)

funname = 'or';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});